TotK DynamicFPS 1.5.1 by /u/ChucksFeedAndSeed
Check https://www.reddit.com/user/ChucksFeedAndSeed/ for updates.

---

If you'd like to support my work I have a ko-fi page at https://ko-fi.com/ChucksFeedAndSeed :)
